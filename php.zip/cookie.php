<?php
/*$data = array('name'=>1,'qzk'=>2)
setcookie('name[0]','qzk');
setcookie('name[1]','qzk1');

 var_dump($_COOKIE['name']);*/

$db_host   = 'localhost';  //数据库主机名称，一般都为localhost
$db_user   = 'root';        //数据库用户帐号，根据个人情况而定
$db_passw = '';   //数据库用户密码，根据个人情况而定
$db_name  = 'zshop';         //数据库具体名称，以刚才创建的数据库为准

if ($conn = @mysqli_connect($db_host,$db_user,$db_passw) ) {
    mysqli_select_db($conn,"zshop");
    mysqli_query($conn,'set names utf8');
    //echo "sdfsd";
}
$sql = 'select * from zh_users';
$res = mysqli_query($conn,$sql);

/*while ($p = mysqli_fetch_array($res)) {
    var_dump($p);
}*/


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>会员管理-会员列表</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
    <link href="pub/bootstrap.css" rel="stylesheet">
    <link href="pub/common.css" rel="stylesheet">
    <script src="pub/jquery-1.11.3.min.js"></script>
    <script src="pub/js/bootstrap.min.js"></script>
    <style>
        body {font-size:18px;}
        table tr td {width:auto;padding-top: 10px;padding-bottom: 10px;}
    </style>
</head>
<body>
<div class="container">
    <table class="table brand-table">
        <thead>
        <tr>
            <th class="pl-20"><input type="checkbox">ID</th>
            <th>会员昵称</th>
            <th>会员等级</th>
            <th>累计消费</th>
            <th>邮件地址</th>
            <th>手机号码</th>
            <th>积分</th>
            <th>注册日期</th>
            <th>操作</th>
        </tr>
        </thead>
        <tbody>
      <  <?php
        while( $p = mysqli_fetch_assoc($res)):
        ?>
            <tr>
                <td class="pl-20"><input type="checkbox">1</td>
                <td><?=$p['user_name']?></td>
                <td><?=$p['user_name']?></td>
                <td><?=$p['user_name']?></td>
                <td><?=$p['user_name']?></td>
                <td>15068953547</td>
                <td>0</td>
                <td>2017-03-06 14:08</td>
                <td><a href="#"><i class="iconfont">&#xe670;</i>编辑</a><a href="#"><i class="iconfont">&#xe670;</i>地址</a><a href="#"><i class="iconfont">&#xe634;</i>资金</a><a href="#"><i class="iconfont">&#xe609;</i>删除</a></td>
            </tr>

      <?php endwhile;?>



        </tbody>
    </table>
</div>

</body>
</html>

